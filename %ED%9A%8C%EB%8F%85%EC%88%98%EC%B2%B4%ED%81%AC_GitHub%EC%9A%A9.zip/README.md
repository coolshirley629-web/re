# 회독 수 체크

사과 이미지를 눌러 과목별 회독을 체크하는 간단한 웹사이트입니다.

## GitHub Pages로 공개하기

1. GitHub에 로그인하고 **New repository**를 눌러 새 저장소를 만듭니다.
2. 저장소 이름을 예를 들어 `study-check`로 정합니다.
3. 저장소에 들어가 **Add file → Upload files**를 선택합니다.
4. 이 폴더 안의 `index.html`을 업로드하고 **Commit changes**를 누릅니다.
5. 저장소의 **Settings → Pages**로 이동합니다.
6. **Build and deployment**에서 `Deploy from a branch`를 선택합니다.
7. Branch는 `main`, 폴더는 `/(root)`로 설정하고 **Save**를 누릅니다.
8. 잠시 기다린 뒤 Pages 화면에 표시되는 주소로 접속합니다.

`index.html`은 저장소의 최상위(root)에 있어야 합니다.
